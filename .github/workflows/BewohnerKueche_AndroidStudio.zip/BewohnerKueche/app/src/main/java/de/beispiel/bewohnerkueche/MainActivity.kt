package de.beispiel.bewohnerkueche

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Resident(val id: Long, val name: String, val room: String, val notes: String)
data class Food(val id: Long, val residentId: Long, val meal: String, val name: String, val quantity: String, val unit: String)

class KitchenDb(context: Context) : SQLiteOpenHelper(context, "bewohner_kueche.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE residents(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, room TEXT DEFAULT '', notes TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE foods(id INTEGER PRIMARY KEY AUTOINCREMENT, residentId INTEGER NOT NULL, meal TEXT NOT NULL, name TEXT NOT NULL, quantity TEXT DEFAULT '', unit TEXT DEFAULT '', FOREIGN KEY(residentId) REFERENCES residents(id) ON DELETE CASCADE)")
        db.execSQL("PRAGMA foreign_keys=ON")
        // Platz für 30 Bewohner; Namen und Daten werden später eingetragen.
        for (i in 1..30) {
            val cv = ContentValues().apply { put("name", "Bewohner $i"); put("room", ""); put("notes", "") }
            db.insert("residents", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun residents(): List<Resident> {
        val out = mutableListOf<Resident>()
        readableDatabase.rawQuery("SELECT id,name,room,notes FROM residents ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out += Resident(c.getLong(0), c.getString(1), c.getString(2) ?: "", c.getString(3) ?: "")
        }
        return out
    }
    fun saveResident(r: Resident) {
        val cv = ContentValues().apply { put("name", r.name); put("room", r.room); put("notes", r.notes) }
        writableDatabase.update("residents", cv, "id=?", arrayOf(r.id.toString()))
    }
    fun foods(residentId: Long, meal: String): List<Food> {
        val out = mutableListOf<Food>()
        readableDatabase.rawQuery("SELECT id,residentId,meal,name,quantity,unit FROM foods WHERE residentId=? AND meal=? ORDER BY name COLLATE NOCASE", arrayOf(residentId.toString(), meal)).use { c ->
            while (c.moveToNext()) out += Food(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4) ?: "", c.getString(5) ?: "")
        }
        return out
    }
    fun addFood(residentId: Long, meal: String, name: String, quantity: String, unit: String) {
        val cv = ContentValues().apply { put("residentId", residentId); put("meal", meal); put("name", name); put("quantity", quantity); put("unit", unit) }
        writableDatabase.insert("foods", null, cv)
    }
    fun deleteFood(id: Long) { writableDatabase.delete("foods", "id=?", arrayOf(id.toString())) }
    fun totals(meal: String): List<Pair<String, String>> {
        val map = linkedMapOf<String, Double>()
        val units = linkedMapOf<String, String>()
        readableDatabase.rawQuery("SELECT name,quantity,unit FROM foods WHERE meal=?", arrayOf(meal)).use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0); val q = c.getString(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
                map[n] = (map[n] ?: 0.0) + q
                units[n] = c.getString(2) ?: ""
            }
        }
        return map.toSortedMap(String.CASE_INSENSITIVE_ORDER).map { (n,q) ->
            val value = if (q % 1.0 == 0.0) q.toInt().toString() else "%.2f".format(q)
            n to "$value ${units[n]}".trim()
        }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var db: KitchenDb
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = KitchenDb(this)
        setContent { MaterialTheme { KitchenApp(db) } }
    }
}

@Composable
fun KitchenApp(db: KitchenDb) {
    var refresh by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Resident?>(null) }
    var totalsMeal by remember { mutableStateOf<String?>(null) }
    val residents = remember(refresh) { db.residents() }

    if (totalsMeal != null) {
        TotalsScreen(db, totalsMeal!!, onBack = { totalsMeal = null }, refresh = refresh)
        return
    }
    if (selected != null) {
        ResidentScreen(db, selected!!, onBack = { selected = null; refresh++ }, onChanged = { refresh++ })
        return
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Bewohner-Küche · 30 Plätze") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("Bewohner alphabetisch", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { totalsMeal = "Frühstück" }, modifier = Modifier.weight(1f)) { Text("Frühstück gesamt") }
                Button(onClick = { totalsMeal = "Abendessen" }, modifier = Modifier.weight(1f)) { Text("Abendessen gesamt") }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn {
                items(residents) { r ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selected = r }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(r.name, style = MaterialTheme.typography.titleMedium)
                            Text(if (r.room.isBlank()) "Zimmer noch offen" else "Zimmer ${r.room}")
                            if (r.notes.isNotBlank()) Text("Besonderheiten: ${r.notes}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResidentScreen(db: KitchenDb, resident: Resident, onBack: () -> Unit, onChanged: () -> Unit) {
    var name by remember(resident.id) { mutableStateOf(resident.name) }
    var room by remember(resident.id) { mutableStateOf(resident.room) }
    var notes by remember(resident.id) { mutableStateOf(resident.notes) }
    var meal by remember { mutableStateOf("Frühstück") }
    var foodName by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("Portion") }
    var refresh by remember { mutableIntStateOf(0) }
    val foods = remember(resident.id, meal, refresh) { db.foods(resident.id, meal) }

    Scaffold(topBar = { TopAppBar(title = { Text("Bewohner bearbeiten") }, navigationIcon = { TextButton(onClick = onBack) { Text("Zurück") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(name, { name = it }, label = { Text("Vor- und Nachname") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(room, { room = it }, label = { Text("Zimmernummer") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(notes, { notes = it }, label = { Text("Besonderheiten / Allergien") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Button(onClick = { if (name.isNotBlank()) { db.saveResident(resident.copy(name=name.trim(), room=room.trim(), notes=notes.trim())); onChanged() } }, modifier = Modifier.fillMaxWidth()) { Text("Bewohnerdaten speichern") }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Lebensmittel", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = meal == "Frühstück", onClick = { meal = "Frühstück" }, label = { Text("Frühstück") })
                FilterChip(selected = meal == "Abendessen", onClick = { meal = "Abendessen" }, label = { Text("Abendessen") })
            }
            OutlinedTextField(foodName, { foodName = it }, label = { Text("Lebensmittel (z. B. Brot)") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(quantity, { quantity = it }, label = { Text("Menge") }, modifier = Modifier.weight(1f))
                OutlinedTextField(unit, { unit = it }, label = { Text("Einheit") }, modifier = Modifier.weight(1f))
            }
            Button(onClick = {
                if (foodName.isNotBlank() && quantity.isNotBlank()) {
                    db.addFood(resident.id, meal, foodName.trim(), quantity.trim(), unit.trim())
                    foodName = ""; quantity = "1"; refresh++
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Lebensmittel hinzufügen") }
            Spacer(Modifier.height(8.dp))
            foods.forEach { f ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${f.name}: ${f.quantity} ${f.unit}".trim(), modifier = Modifier.weight(1f))
                        TextButton(onClick = { db.deleteFood(f.id); refresh++ }) { Text("Löschen") }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TotalsScreen(db: KitchenDb, meal: String, onBack: () -> Unit, refresh: Int) {
    val totals = remember(meal, refresh) { db.totals(meal) }
    Scaffold(topBar = { TopAppBar(title = { Text("Gesamtbedarf: $meal") }, navigationIcon = { TextButton(onClick = onBack) { Text("Zurück") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("Zusammenrechnung aller eingetragenen Bewohner", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            if (totals.isEmpty()) Text("Noch keine Lebensmittel eingetragen.")
            totals.forEach { (name, amount) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name)
                        Text(amount, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
