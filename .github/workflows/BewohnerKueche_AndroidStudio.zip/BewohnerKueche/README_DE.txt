BEWOHNER-KÜCHE – Android-Studio-Projekt

Enthalten:
- 30 vorbereitete Bewohner-Plätze (Bewohner 1 bis Bewohner 30)
- Bewohnerdaten: Name, Zimmernummer, Besonderheiten/Allergien
- Lebensmittel getrennt nach Frühstück und Abendessen
- Individuelle Menge und Einheit je Lebensmittel
- Gesamtbedarf getrennt nach Frühstück und Abendessen
- Speicherung lokal in SQLite, kein Internet erforderlich

Öffnen:
1. ZIP entpacken.
2. Android Studio starten.
3. File > Open wählen und den Ordner BewohnerKueche öffnen.
4. Gradle-Synchronisierung abwarten.
5. Android-Tablet/Handy per USB verbinden und Run drücken.

Hinweise:
- Beim ersten Start sind 30 Platzhalter angelegt. Diese können einzeln geöffnet und umbenannt werden.
- Mengen werden für die Gesamtliste addiert, wenn Lebensmittel denselben Namen haben. Bitte gleiche Einheiten verwenden (z. B. immer "Scheiben").
- Dies ist eine erste funktionsfähige Grundversion. Vor echtem Einsatz bitte mit Testdaten prüfen und regelmäßig Android-Backups erstellen.
- Für sensible Bewohnerdaten Gerätesperre aktivieren und das Tablet nicht öffentlich zugänglich lassen.
